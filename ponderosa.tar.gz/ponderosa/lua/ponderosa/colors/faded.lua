local lush = require('lush')
local hsluv = lush.hsluv

local get = function()
    return {
        vanilla = hsluv(54, 50, 50),
        grass = hsluv(130, 45, 80),
        moss = hsluv(110, 50, 91),
        -- aqua = hsluv(250, 50, 60),
        bark = hsluv(26, 30, 59),
        autumn = hsluv(32, 35, 68),
        aspen = hsluv(77, 50, 88),
        paintbrush = hsluv(16, 50, 56),
        thistle = hsluv(286, 50, 52),
        stellar = hsluv(260, 50, 56), -- Stellar's Jay
        -- huckleberry = hsluv(270, 50, 30),
        sky = hsluv(235, 51, 80),
        cloud = hsluv(247, 2, 95),
        sand = hsluv(253, 50, 83),
        -- night = hsluv(253, 49, 22),
        canopy = hsluv(130, 65, 20),
        tan = hsluv(60, 40, 80),

        fg2 = hsluv(247, 2, 87),
        fg3 = hsluv(247, 2, 71),
        fg4 = hsluv(247, 2, 55),
        fg5 = hsluv(247, 2, 39),

        dark_bg = hsluv(130, 45, 14),
        bg2 = hsluv(130, 45, 26),
        bg3 = hsluv(130, 45, 32),
        bg4 = hsluv(130, 45, 36),
    }
end

return get
