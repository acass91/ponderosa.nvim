local lush = require('lush')
local hsluv = lush.hsluv

local get = function()
    return {
        vanilla = hsluv(54, 100, 50),
        grass = hsluv(130, 79, 80),
        moss = hsluv(110, 100, 91),
        -- aqua = hsluv(250, 91, 60),
        bark = hsluv(26, 52, 59),
        autumn = hsluv(32, 50, 68),
        aspen = hsluv(77, 100, 88),
        paintbrush = hsluv(16, 100, 56),
        thistle = hsluv(286, 100, 52),
        stellar = hsluv(260, 100, 56), -- Stellar's Jay
        -- huckleberry = hsluv(270, 94, 30),
        sky = hsluv(235, 100, 80),
        cloud = hsluv(247, 2, 95),
        sand = hsluv(253, 81, 83),
        -- night = hsluv(253, 49, 22),
        canopy = hsluv(130, 65, 20),
        tan = hsluv(60, 60, 80),

        fg2 = hsluv(247, 2, 87),
        fg3 = hsluv(247, 2, 71),
        fg4 = hsluv(247, 2, 55),
        fg5 = hsluv(247, 2, 39),

        dark_bg = hsluv(130, 65, 14),
        bg2 = hsluv(130, 65, 26),
        bg3 = hsluv(130, 65, 32),
        bg4 = hsluv(130, 65, 36),
    }
end

return get
