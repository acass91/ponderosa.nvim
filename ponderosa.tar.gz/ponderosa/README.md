A Lush Theme for Neovim.
===

See: http://git.io/lush.nvim for more information on Lush and a helper script
to setup your repo clone.
